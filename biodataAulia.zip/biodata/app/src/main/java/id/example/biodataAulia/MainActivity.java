package id.example.biodataAulia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button alamat, telp, email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        alamat = findViewById(R.id.alamat);
        telp = findViewById(R.id.telp);
        email = findViewById(R.id.telp);

        alamat.setOnClickListener(this);
        telp.setOnClickListener(this);
        email.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.alamat:
                String map = "http://maps.google.co.in/maps?q=" + "Puri,+Kec.+Pati,+Kabupaten+Pati,+Jawa+Tengah";
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(map));
                startActivity(i);
                break;
            case R.id.telp:
                String phone = "+6285727595310";
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null));
                startActivity(intent);
                break;
            case R.id.email:
                Intent i2 = new Intent(Intent.ACTION_SENDTO);
                i2.setData(Uri.parse("mailto:")); // only email apps should handle this
                i2.putExtra(Intent.EXTRA_EMAIL, "auliaekacp@gmail.com");
                i2.putExtra(Intent.EXTRA_SUBJECT, "Perkenalan Dengan Aulia");
                if (i2.resolveActivity(getPackageManager()) != null) {
                    startActivity(i2);
                }
                break;
        }
    }
}